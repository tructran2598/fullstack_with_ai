// 1. Variables and Data Types:
let x; // declare a variable x
x = 10; // assign the value 10 to it
const y = "Hello"; // declare a variable y with the value “Hello”
const z = x + y; // concatenate x & y
console.log(z); // z = “10Hello”

// 2. Control Flow:
if (x % 2 === 0) {
  // check if x is divisible by 2
  console.log("Even"); // print “Even” if x is even
} else {
  console.log("Odd"); // print “Odd” if x is odd
}

// 3. Functions:
function greetUser(name) {
  console.log(`Hello, [${name}]!`); // print “Hello” followed by the name
}
greetUser("Alice"); // call the function greetUser with the argument Alice
greetUser("Bob"); // call the function greetUser with the argument Bob
greetUser("Charlie"); // call the function greetUser with the argument Charlie
// functions can be called multiple times with different arguments, we no need to write the same code multiple times
