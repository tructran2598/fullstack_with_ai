// 1.
let name = "Henry";
let age = 30;
let isStudent = false;

name = "Alice";
age = 22;
isStudent = true;

console.log(name);
console.log(age);
console.log(isStudent);

// 2.
let userInput = prompt("Please enter a number:");
let number = parseFloat(userInput);

if (number > 0) {
  alert("The number is positive.");
} else if (number < 0) {
  alert("The number is negative.");
} else {
  alert("The number is zero.");
}

// 3.
let fruits = ["apple", "banana", "orange", "grape"];

for (let i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
}

// 4.
function calculateArea(length, width) {
  return length * width;
}

let rectangleLength = 10;
let rectangleWidth = 30;
let area = calculateArea(rectangleLength, rectangleWidth);
console.log("The area of the rectangle is ", area);

// 5.
