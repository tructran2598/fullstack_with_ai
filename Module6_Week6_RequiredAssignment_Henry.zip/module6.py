# 1
name = "Henry"
age = 30
height_cm = 170
print(f"Hello, {name}!")

age_in_10_years = age + 10
print(f"In 10 years, {name} will be {age_in_10_years} years old.")

height_m = height_cm / 100
print(f"{name}'s height is {height_m} meters.")

#2
number = float(input("Enter a number: "))
if number > 0:
    print("The number is positive.")
elif number < 0:
    print("The number is negative.")
else:
    print("The number is zero.")

# 3
n = int(input("Enter an integer nnn: "))
for i in range(2, n + 1, 2):
    print(i)

# 4
def calc_rectangle_area(rectangle_length, rectangle_width):
    return rectangle_length * rectangle_width

length = float(input("Length of the rectangle: "))
width = float(input("Width of the rectangle: "))
area = calc_rectangle_area(length, width)
print(f"The area of the rectangle with length {length} and width {width} is: {area}")

